This folder is for your private projects.
Files in this folder will not be synced to GitHub.
