This folder is for your projects.
